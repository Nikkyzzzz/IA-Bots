# Integrated Data Extraction Tool

This project integrates the Banking Analysis tool with PDF Data Extraction capabilities, providing a comprehensive solution for financial data processing and analysis.

## Features

### Banking Analysis (Original Features)
- Upload and analyze loan dump files
- Process blacklisted PIN code files
- Compare loan book data across periods
- Generate compliance reports
- Automated bot analysis for various banking scenarios

### PDF Data Extraction (New Integration)
- Upload PDF files containing loan and project information
- AI-powered data extraction using Cohere API
- Automated compliance checking
- Fee calculation based on loan amounts
- Background processing with progress tracking
- Results displayed in structured table format

## How It Works

1. **File Upload**: Navigate to Banking Home and use the tabs to upload either:
   - Banking data files (Excel/XLS) for traditional analysis
   - PDF files for AI-powered data extraction

2. **PDF Processing**: When PDFs are uploaded:
   - Processing starts automatically in the background
   - Progress can be monitored in the "Data Extraction" tab in results
   - No user intervention required during processing

3. **Results**: View results in the Banking Dashboard:
   - Traditional banking analysis in Analysis/Output/Report tabs
   - PDF extraction results in the new "Data Extraction" tab

## Installation

1. Install required dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Set up your environment:
   - Copy `.env.example` to `.env`
   - Add your Cohere API key to the `.env` file:
     ```
     COHERE_API_KEY=your_api_key_here
     ```

3. Run the application:
   ```bash
   streamlit run zeropage.py
   ```

## Usage

### PDF Data Extraction Workflow

1. **Upload**: Go to Banking Home → PDF Data Extraction tab
2. **Upload Files**: Select one or more PDF files containing loan/project data
3. **Automatic Processing**: Processing starts in background immediately
4. **View Results**: Navigate to Banking Dashboard → Data Extraction tab
5. **Download**: Export results as Excel file

### Key Features of PDF Extraction

- **Automated Data Extraction**: Extracts 14 key financial parameters
- **Compliance Checking**: Validates extracted data against standard criteria
- **Fee Calculation**: Automatically calculates registration and front-end fees
- **Background Processing**: No blocking UI during extraction
- **Progress Tracking**: Real-time progress updates
- **Excel Export**: Download structured results

## Extracted Data Fields

1. Project Number
2. Loan Amount
3. Project Type & Sector
4. Grade/Rating
5. Interest Rate
6. Project Cost
7. Promoter Contribution
8. Minimum Promoter Contribution %
9. Debt Equity Ratio
10. Average DSCR (new clients)
11. Average DSCR Requirement
12. Average Asset Coverage Ratio
13. Contingent Liability
14. Moratorium/Grace Period

## Technical Details

- **Frontend**: Streamlit with custom styling
- **AI Engine**: Cohere API for document analysis
- **PDF Processing**: pdfplumber for text extraction
- **Data Processing**: pandas for data manipulation
- **Export**: xlsxwriter for Excel generation

## File Structure

- `zeropage.py` - Main application entry point and routing
- `b1.py` - File upload interface (includes PDF upload tab)
- `b7.py` - Results dashboard (includes Data Extraction tab)
- `pdf_extraction.py` - PDF processing and AI extraction logic
- Other `b*.py` files - Original banking analysis modules
- `requirements.txt` - Python dependencies
- `.env` - Environment configuration (API keys)

## Integration Points

The PDF extraction functionality is seamlessly integrated into the existing banking tool:

- **Upload Integration**: PDF upload added as a tab in `b1.py`
- **Results Integration**: Data Extraction tab added to `b7.py`
- **Background Processing**: Non-blocking processing with session state management
- **Unified Navigation**: Uses existing page routing system

## Note

This tool requires a valid Cohere API key for PDF data extraction functionality. The banking analysis features work independently without the API key.