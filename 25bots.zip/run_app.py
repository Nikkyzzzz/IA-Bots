"""
Main application runner for the Integrated Data Extraction tool
This integrates the original Banking analysis tool with PDF data extraction capabilities
"""

# Run the main app through zeropage.py which handles the routing
exec(open('zeropage.py').read())